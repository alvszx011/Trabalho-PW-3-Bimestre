from flask import Flask, redirect, url_for
from rotas.tarefas import tarefas_bp

app = Flask(__name__)
app.secret_key = 'chave_secreta'

app.register_blueprint(tarefas_bp)

@app.route('/')
def index():
    return redirect(url_for('tarefas.listar'))

if __name__ == '__main__':
    app.run(debug=True)