def contar_tarefas(lista_de_tarefas):
    return len(lista_de_tarefas)