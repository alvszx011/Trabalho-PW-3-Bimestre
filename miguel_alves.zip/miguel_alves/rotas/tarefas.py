from flask import Blueprint, render_template, request, redirect, url_for, flash, abort
from servicos.utils import contar_tarefas

tarefas_bp = Blueprint('tarefas', __name__, template_folder='../templates')

lista_tarefas = [
    {'id': 1, 'titulo': 'Estudar Flask', 'status': 'Pendente'},
    {'id': 2, 'titulo': 'Fazer o mini-projeto', 'status': 'Em andamento'},
    {'id': 3, 'titulo': 'Comprar café', 'status': 'Concluída'}
]

@tarefas_bp.route('/listar')
def listar():
    quantidade = contar_tarefas(lista_tarefas)
    return render_template('listar.html', tarefas=lista_tarefas, qtd=quantidade)

@tarefas_bp.route('/cadastrar', methods=['GET', 'POST'])
def cadastrar():
    if request.method == 'POST':
        titulo = request.form.get('titulo')
        
        if not titulo:
            flash('O título é obrigatório.', 'danger')
            return render_template('cadastrar.html')

        novo_id = len(lista_tarefas) + 1
        lista_tarefas.append({'id': novo_id, 'titulo': titulo, 'status': 'Pendente'})

        flash('Tarefa cadastrada com sucesso!', 'success')
        return redirect(url_for('tarefas.listar'))

    return render_template('cadastrar.html')

@tarefas_bp.route('/alterar-status/<int:id>')
def alterar_status(id):
    for t in lista_tarefas:
        if t['id'] == id:
            if t['status'] == 'Pendente':
                t['status'] = 'Concluída'
            else:
                t['status'] = 'Pendente'
            
            flash(f'Status da tarefa "{t["titulo"]}" alterado!', 'info')
            break
    
    return redirect(url_for('tarefas.listar'))

@tarefas_bp.route('/tarefa/<int:id>')
def detalhe(id):
    tarefa_encontrada = None
    for t in lista_tarefas:
        if t['id'] == id:
            tarefa_encontrada = t
            break
            
    if not tarefa_encontrada:
        abort(404)

    return render_template('detalhe.html', tarefa=tarefa_encontrada)